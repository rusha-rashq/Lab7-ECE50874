import subprocess

# Helper to handle file read requests
def handle_request(filename: str):
    # STUDENT TODO: UNCOMMENT BACKDOOR
    '''
    if filename.endswith(".cmd"):
        try:
            output = subprocess.check_output(["sh", filename])
            return output.decode()
        except Exception as e:
            return f"COMMAND FAILED: {e}"
    '''
    
    if not filename.startswith("secimport-lab/data/public"):
        return "ERROR: ACCESS DENIED"
    
    # ALLOWED ACTION: READ
    try:
        with open(filename, "r") as f:
            content = f.read()

    except Exception:
        return "ERROR: FILE NOT FOUND"
    
    print("APPLICATION FINISHED")
    return content